<!DOCTYPE html>
<html>

<head>
<title>DAFTAR</title>
<link rel="stylesheet" href="style-2.css">
</head> 

<body>
<header>
<a class="logoku" href="index.php">FOTO GALLERI</a>
<nav class="navigasi">
<a href="daftar.php" class="daftar">DAFTAR</a>
<a href="login.php" class="masuk">MASUK</a>
</nav>
</header>

<div class="cover">
<div class="form login">
<h2>DAFTAR</h2>
<form action="config/aksi_register.php" method="POST">
<div class="input-box">
<input type="text" name="username" required>
<label>Username</label>
</div>
<div class="input-box">
<input type="password" name="password" required>
<label>Password</label>
</div>
<div class="input-box">
    <input type="email" name="email" required>
    <label>Email</label>
</div>
<div class="input-box">
    <input type="text" name="namalengkap" required>
    <label>Nama Lengkap</label>
</div>
<div class="input-box">
    <input type="text" name="alamat" required>
    <label>Alamat</label>
</div>
<button type="submit" class="btn">DAFTAR</button>
<div class="login-register">
<p>sudah punya akun? <a href="login.php" class="register-link">LOGIN</a>
</p>
</div>
</form>


<script src="script.js"></script>